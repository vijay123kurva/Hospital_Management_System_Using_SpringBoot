import React from 'react';
import Modal from './Modal';

export default function ConfirmDialog({ title, message, name, onConfirm, onCancel, loading }) {
  return (
    <Modal
      title={title || 'Confirm Delete'}
      onClose={onCancel}
      footer={
        <>
          <button className="btn btn-outline" onClick={onCancel} disabled={loading}>Cancel</button>
          <button className="btn btn-danger" onClick={onConfirm} disabled={loading}>
            {loading ? 'Deleting…' : 'Delete'}
          </button>
        </>
      }
    >
      <p className="confirm-msg">
        Are you sure you want to delete{' '}
        <span className="confirm-name">{name}</span>?
        {message && <><br />{message}</>}
        <br />This action cannot be undone.
      </p>
    </Modal>
  );
}

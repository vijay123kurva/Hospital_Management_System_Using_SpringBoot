import axios from 'axios';

const API = axios.create({
  baseURL: 'http://localhost:8080/api',
  headers: { 'Content-Type': 'application/json' },
});

// ── Dashboard ──────────────────────────────────────────
export const getDashboard = () => API.get('/dashboard');

// ── Patients ───────────────────────────────────────────
export const getPatients  = (search) => API.get('/patients', { params: search ? { search } : {} });
export const getPatient   = (id)     => API.get(`/patients/${id}`);
export const createPatient= (data)   => API.post('/patients', data);
export const updatePatient= (id, data) => API.put(`/patients/${id}`, data);
export const deletePatient= (id)     => API.delete(`/patients/${id}`);

// ── Doctors ────────────────────────────────────────────
export const getDoctors   = (search) => API.get('/doctors', { params: search ? { search } : {} });
export const getDoctor    = (id)     => API.get(`/doctors/${id}`);
export const createDoctor = (data)   => API.post('/doctors', data);
export const updateDoctor = (id, data) => API.put(`/doctors/${id}`, data);
export const deleteDoctor = (id)     => API.delete(`/doctors/${id}`);

// ── Departments ────────────────────────────────────────
export const getDepartments   = () => API.get('/departments');
export const getDepartment    = (id) => API.get(`/departments/${id}`);
export const createDepartment = (data) => API.post('/departments', data);
export const updateDepartment = (id, data) => API.put(`/departments/${id}`, data);
export const deleteDepartment = (id) => API.delete(`/departments/${id}`);

// ── Appointments ───────────────────────────────────────
export const getAppointments   = () => API.get('/appointments');
export const getAppointment    = (id) => API.get(`/appointments/${id}`);
export const createAppointment = (data) => API.post('/appointments', data);
export const updateAppointment = (id, data) => API.put(`/appointments/${id}`, data);
export const updateAppointmentStatus = (id, status) => API.patch(`/appointments/${id}/status`, { status });
export const deleteAppointment = (id) => API.delete(`/appointments/${id}`);
export const getAppointmentsByPatient = (patientId) => API.get(`/appointments/patient/${patientId}`);
export const getAppointmentsByDoctor  = (doctorId)  => API.get(`/appointments/doctor/${doctorId}`);

// ── Insurance ──────────────────────────────────────────
export const getInsurances   = () => API.get('/insurances');
export const getInsurance    = (id) => API.get(`/insurances/${id}`);
export const createInsurance = (data) => API.post('/insurances', data);
export const updateInsurance = (id, data) => API.put(`/insurances/${id}`, data);
export const deleteInsurance = (id) => API.delete(`/insurances/${id}`);

export default API;

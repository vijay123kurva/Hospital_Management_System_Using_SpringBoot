import React from 'react';
import { BrowserRouter, Routes, Route, NavLink, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import Dashboard from './pages/Dashboard';
import Patients from './pages/Patients';
import Doctors from './pages/Doctors';
import Departments from './pages/Departments';
import Appointments from './pages/Appointments';
import Insurance from './pages/Insurance';

const NAV = [
  { to: '/',            icon: '📊', label: 'Dashboard'    },
  { to: '/patients',    icon: '🧑‍⚕️', label: 'Patients'     },
  { to: '/doctors',     icon: '👨‍⚕️', label: 'Doctors'      },
  { to: '/departments', icon: '🏥', label: 'Departments'  },
  { to: '/appointments',icon: '📅', label: 'Appointments' },
  { to: '/insurance',   icon: '🛡️', label: 'Insurance'    },
];

function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="sidebar-logo">
        <h1>MediCore</h1>
        <span>Hospital Management</span>
      </div>
      <nav className="sidebar-nav">
        <div className="nav-section-label">Main Menu</div>
        {NAV.map(n => (
          <NavLink
            key={n.to}
            to={n.to}
            end={n.to === '/'}
            className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}
          >
            <span className="nav-icon">{n.icon}</span>
            {n.label}
          </NavLink>
        ))}
      </nav>
      <div style={{ padding: '16px 20px', borderTop: '1px solid rgba(255,255,255,.1)' }}>
        <div style={{ fontSize: '.72rem', color: 'rgba(255,255,255,.35)', lineHeight: 1.6 }}>
          MediCore v1.0<br />
          Spring Boot + PostgreSQL
        </div>
      </div>
    </aside>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Toaster position="top-right" toastOptions={{ duration: 3000 }} />
      <div className="app-layout">
        <Sidebar />
        <div className="main-content">
          <Routes>
            <Route path="/"             element={<Dashboard />} />
            <Route path="/patients"     element={<Patients />} />
            <Route path="/doctors"      element={<Doctors />} />
            <Route path="/departments"  element={<Departments />} />
            <Route path="/appointments" element={<Appointments />} />
            <Route path="/insurance"    element={<Insurance />} />
            <Route path="*"             element={<Navigate to="/" />} />
          </Routes>
        </div>
      </div>
    </BrowserRouter>
  );
}

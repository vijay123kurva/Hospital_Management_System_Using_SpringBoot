import React, { useEffect, useState } from 'react';
import { getDashboard } from '../services/api';

const STATS = [
  { key: 'totalPatients',    label: 'Total Patients',    icon: '🧑‍⚕️', color: '#0f4c81', bg: '#e8f1fb' },
  { key: 'totalDoctors',     label: 'Total Doctors',     icon: '👨‍⚕️', color: '#00b4a2', bg: '#e0f7f5' },
  { key: 'totalDepartments', label: 'Departments',       icon: '🏥', color: '#7c3aed', bg: '#f3eeff' },
  { key: 'totalAppointments',label: 'Appointments',      icon: '📅', color: '#d69e2e', bg: '#fffbeb' },
  { key: 'scheduledAppointments', label: 'Scheduled',    icon: '⏳', color: '#2b6cb0', bg: '#ebf8ff' },
  { key: 'completedAppointments', label: 'Completed',    icon: '✅', color: '#38a169', bg: '#f0fff4' },
  { key: 'cancelledAppointments', label: 'Cancelled',    icon: '❌', color: '#e53e3e', bg: '#fff5f5' },
  { key: 'totalInsurances',  label: 'Insurance Policies',icon: '🛡️', color: '#dd6b20', bg: '#fff7ed' },
];

export default function Dashboard() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getDashboard()
      .then(r => setStats(r.data))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  return (
    <>
      <div className="topbar">
        <span className="topbar-title">Dashboard</span>
        <span className="topbar-badge">Overview</span>
      </div>
      <div className="page-body">
        <div className="page-header">
          <div className="page-header-left">
            <h2>Welcome to MediCore</h2>
            <p>Here's what's happening in your hospital today.</p>
          </div>
        </div>

        {loading ? <div className="spinner" /> : (
          <div className="stats-grid">
            {STATS.map(s => (
              <div className="stat-card" key={s.key}>
                <div className="stat-icon" style={{ background: s.bg, color: s.color }}>
                  {s.icon}
                </div>
                <div className="stat-info">
                  <div className="stat-value">{stats?.[s.key] ?? 0}</div>
                  <div className="stat-label">{s.label}</div>
                </div>
              </div>
            ))}
          </div>
        )}

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
          <div className="card">
            <div className="card-header"><span className="card-title">📋 Quick Guide</span></div>
            <div className="card-body" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {[
                ['Patients', 'Register and manage patient records with insurance linkage'],
                ['Doctors',  'Add doctors and assign them to departments'],
                ['Departments', 'Manage hospital departments and assign head doctors'],
                ['Appointments', 'Book, update, and track patient appointments'],
                ['Insurance', 'Manage insurance policies linked to patients'],
              ].map(([t, d]) => (
                <div key={t} style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
                  <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--primary)', marginTop: 6, flexShrink: 0 }} />
                  <div>
                    <div style={{ fontWeight: 700, fontSize: '.875rem' }}>{t}</div>
                    <div style={{ fontSize: '.8rem', color: 'var(--text-secondary)' }}>{d}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="card">
            <div className="card-header"><span className="card-title">🔧 System Info</span></div>
            <div className="card-body" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {[
                ['Backend', 'Spring Boot 3.2 + JDK 21'],
                ['Database', 'PostgreSQL'],
                ['ORM', 'Spring Data JPA / Hibernate'],
                ['API', 'RESTful JSON API on port 8080'],
                ['Frontend', 'React 18 + React Router v6'],
              ].map(([k, v]) => (
                <div key={k} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
                  <span style={{ fontSize: '.82rem', color: 'var(--text-secondary)', fontWeight: 600 }}>{k}</span>
                  <span style={{ fontSize: '.82rem', fontWeight: 600, background: 'var(--primary-pale)', color: 'var(--primary)', padding: '2px 10px', borderRadius: 20 }}>{v}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

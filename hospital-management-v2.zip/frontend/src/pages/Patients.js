import React, { useEffect, useState, useCallback } from 'react';
import toast from 'react-hot-toast';
import Modal from '../components/Modal';
import ConfirmDialog from '../components/ConfirmDialog';
import {
  getPatients, createPatient, updatePatient, deletePatient,
  getInsurances,
} from '../services/api';

const BLOOD_GROUPS = ['A+','A-','B+','B-','AB+','AB-','O+','O-'];
const GENDERS      = ['Male','Female','Other'];

const EMPTY = {
  name: '', gender: '', birthDate: '', email: '',
  bloodGroup: '', insuranceId: '',
};

export default function Patients() {
  const [patients,   setPatients]   = useState([]);
  const [insurances, setInsurances] = useState([]);
  const [loading,    setLoading]    = useState(true);
  const [search,     setSearch]     = useState('');
  const [showForm,   setShowForm]   = useState(false);
  const [editing,    setEditing]    = useState(null);
  const [form,       setForm]       = useState(EMPTY);
  const [saving,     setSaving]     = useState(false);
  const [delTarget,  setDelTarget]  = useState(null);
  const [deleting,   setDeleting]   = useState(false);

  const load = useCallback(() => {
    setLoading(true);
    Promise.all([getPatients(search), getInsurances()])
      .then(([p, i]) => { setPatients(p.data); setInsurances(i.data); })
      .catch(() => toast.error('Failed to load data'))
      .finally(() => setLoading(false));
  }, [search]);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => { setEditing(null); setForm(EMPTY); setShowForm(true); };
  const openEdit   = p  => {
    setEditing(p);
    setForm({
      name: p.name || '', gender: p.gender || '',
      birthDate: p.birthDate || '', email: p.email || '',
      bloodGroup: p.bloodGroup || '',
      insuranceId: p.insuranceId || '',
    });
    setShowForm(true);
  };

  const handleSave = async () => {
    if (!form.name.trim()) { toast.error('Name is required'); return; }
    setSaving(true);
    try {
      const payload = { ...form, insuranceId: form.insuranceId || null };
      if (editing) {
        await updatePatient(editing.id, payload);
        toast.success('Patient updated');
      } else {
        await createPatient(payload);
        toast.success('Patient created');
      }
      setShowForm(false);
      load();
    } catch {
      toast.error('Save failed');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await deletePatient(delTarget.id);
      toast.success('Patient deleted');
      setDelTarget(null);
      load();
    } catch {
      toast.error('Delete failed');
    } finally {
      setDeleting(false);
    }
  };

  const f = (k) => e => setForm(p => ({ ...p, [k]: e.target.value }));

  return (
    <>
      <div className="topbar">
        <span className="topbar-title">Patients</span>
        <span className="topbar-badge">{patients.length} records</span>
      </div>

      <div className="page-body">
        <div className="page-header">
          <div className="page-header-left">
            <h2>Patient Management</h2>
            <p>Register and manage hospital patients</p>
          </div>
          <button className="btn btn-primary" onClick={openCreate}>＋ Add Patient</button>
        </div>

        <div className="card">
          <div className="card-header">
            <span className="card-title">All Patients</span>
            <div className="action-row">
              <div className="search-bar">
                <span className="search-icon">🔍</span>
                <input
                  placeholder="Search by name…"
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                />
              </div>
            </div>
          </div>

          <div className="table-wrap">
            {loading ? <div className="spinner" /> : patients.length === 0 ? (
              <div className="empty-state">
                <div className="empty-icon">🧑‍⚕️</div>
                <p>No patients found. Add your first patient.</p>
              </div>
            ) : (
              <table>
                <thead>
                  <tr>
                    <th>Name</th><th>Gender</th><th>Blood</th>
                    <th>Email</th><th>Insurance</th><th>Registered</th><th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {patients.map(p => (
                    <tr key={p.id}>
                      <td><strong>{p.name}</strong></td>
                      <td>{p.gender || '—'}</td>
                      <td>
                        {p.bloodGroup
                          ? <span className="badge badge-scheduled">{p.bloodGroup}</span>
                          : '—'}
                      </td>
                      <td>{p.email || '—'}</td>
                      <td>{p.insurancePolicyNumber
                        ? <span className="badge badge-completed">{p.insurancePolicyNumber}</span>
                        : <span style={{ color: 'var(--text-muted)', fontSize: '.8rem' }}>None</span>}
                      </td>
                      <td style={{ color: 'var(--text-secondary)', fontSize: '.82rem' }}>
                        {p.createdAt ? new Date(p.createdAt).toLocaleDateString() : '—'}
                      </td>
                      <td>
                        <div className="action-row">
                          <button className="btn btn-outline btn-sm" onClick={() => openEdit(p)}>✏️ Edit</button>
                          <button className="btn btn-danger btn-sm" onClick={() => setDelTarget(p)}>🗑️</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>

      {showForm && (
        <Modal
          title={editing ? 'Edit Patient' : 'Add Patient'}
          onClose={() => setShowForm(false)}
          footer={
            <>
              <button className="btn btn-outline" onClick={() => setShowForm(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleSave} disabled={saving}>
                {saving ? 'Saving…' : editing ? 'Update' : 'Create'}
              </button>
            </>
          }
        >
          <div className="form-grid">
            <div className="form-group">
              <label className="form-label">Full Name *</label>
              <input className="form-control" value={form.name} onChange={f('name')} placeholder="John Doe" />
            </div>
            <div className="form-group">
              <label className="form-label">Gender</label>
              <select className="form-control" value={form.gender} onChange={f('gender')}>
                <option value="">Select gender</option>
                {GENDERS.map(g => <option key={g} value={g}>{g}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Date of Birth</label>
              <input className="form-control" type="date" value={form.birthDate} onChange={f('birthDate')} />
            </div>
            <div className="form-group">
              <label className="form-label">Email</label>
              <input className="form-control" type="email" value={form.email} onChange={f('email')} placeholder="john@email.com" />
            </div>
            <div className="form-group">
              <label className="form-label">Blood Group</label>
              <select className="form-control" value={form.bloodGroup} onChange={f('bloodGroup')}>
                <option value="">Select blood group</option>
                {BLOOD_GROUPS.map(b => <option key={b} value={b}>{b}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Insurance Policy</label>
              <select className="form-control" value={form.insuranceId} onChange={f('insuranceId')}>
                <option value="">No insurance</option>
                {insurances.map(i => (
                  <option key={i.id} value={i.id}>{i.policyNumber} — {i.provider}</option>
                ))}
              </select>
            </div>
          </div>
        </Modal>
      )}

      {delTarget && (
        <ConfirmDialog
          name={delTarget.name}
          onConfirm={handleDelete}
          onCancel={() => setDelTarget(null)}
          loading={deleting}
        />
      )}
    </>
  );
}

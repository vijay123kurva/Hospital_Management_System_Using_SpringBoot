import React, { useEffect, useState, useCallback } from 'react';
import toast from 'react-hot-toast';
import Modal from '../components/Modal';
import ConfirmDialog from '../components/ConfirmDialog';
import {
  getAppointments, createAppointment, updateAppointment,
  deleteAppointment, updateAppointmentStatus, getDoctors, getPatients,
} from '../services/api';

const STATUSES = ['SCHEDULED', 'COMPLETED', 'CANCELLED'];
const EMPTY = { appointmentTime: '', reason: '', status: 'SCHEDULED', doctorId: '', patientId: '' };

const statusBadge = s => {
  const map = { SCHEDULED: 'badge-scheduled', COMPLETED: 'badge-completed', CANCELLED: 'badge-cancelled' };
  return <span className={`badge ${map[s] || 'badge-warning'}`}>{s}</span>;
};

export default function Appointments() {
  const [appointments, setAppointments] = useState([]);
  const [doctors,      setDoctors]      = useState([]);
  const [patients,     setPatients]     = useState([]);
  const [loading,      setLoading]      = useState(true);
  const [filter,       setFilter]       = useState('ALL');
  const [showForm,     setShowForm]     = useState(false);
  const [editing,      setEditing]      = useState(null);
  const [form,         setForm]         = useState(EMPTY);
  const [saving,       setSaving]       = useState(false);
  const [delTarget,    setDelTarget]    = useState(null);
  const [deleting,     setDeleting]     = useState(false);

  const load = useCallback(() => {
    setLoading(true);
    Promise.all([getAppointments(), getDoctors(), getPatients()])
      .then(([a, d, p]) => { setAppointments(a.data); setDoctors(d.data); setPatients(p.data); })
      .catch(() => toast.error('Failed to load'))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { load(); }, [load]);

  const filtered = filter === 'ALL' ? appointments : appointments.filter(a => a.status === filter);

  const openCreate = () => { setEditing(null); setForm(EMPTY); setShowForm(true); };
  const openEdit   = a => {
    setEditing(a);
    setForm({
      appointmentTime: a.appointmentTime ? a.appointmentTime.slice(0, 16) : '',
      reason: a.reason || '', status: a.status || 'SCHEDULED',
      doctorId: a.doctorId || '', patientId: a.patientId || '',
    });
    setShowForm(true);
  };

  const handleSave = async () => {
    if (!form.appointmentTime) { toast.error('Appointment time is required'); return; }
    if (!form.doctorId)        { toast.error('Doctor is required'); return; }
    if (!form.patientId)       { toast.error('Patient is required'); return; }
    setSaving(true);
    try {
      const payload = { ...form, doctorId: Number(form.doctorId), patientId: Number(form.patientId) };
      if (editing) {
        await updateAppointment(editing.id, payload);
        toast.success('Appointment updated');
      } else {
        await createAppointment(payload);
        toast.success('Appointment booked');
      }
      setShowForm(false);
      load();
    } catch { toast.error('Save failed'); }
    finally { setSaving(false); }
  };

  const handleStatusChange = async (appt, newStatus) => {
    try {
      await updateAppointmentStatus(appt.id, newStatus);
      toast.success(`Marked as ${newStatus}`);
      load();
    } catch { toast.error('Status update failed'); }
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await deleteAppointment(delTarget.id);
      toast.success('Appointment deleted');
      setDelTarget(null);
      load();
    } catch { toast.error('Delete failed'); }
    finally { setDeleting(false); }
  };

  const f = k => e => setForm(p => ({ ...p, [k]: e.target.value }));

  return (
    <>
      <div className="topbar">
        <span className="topbar-title">Appointments</span>
        <span className="topbar-badge">{appointments.length} total</span>
      </div>
      <div className="page-body">
        <div className="page-header">
          <div className="page-header-left">
            <h2>Appointment Management</h2>
            <p>Book and manage patient appointments</p>
          </div>
          <button className="btn btn-primary" onClick={openCreate}>＋ Book Appointment</button>
        </div>

        <div className="card">
          <div className="card-header">
            <span className="card-title">Appointments</span>
            <div className="action-row">
              {['ALL', ...STATUSES].map(s => (
                <button
                  key={s}
                  className={`btn btn-sm ${filter === s ? 'btn-primary' : 'btn-outline'}`}
                  onClick={() => setFilter(s)}
                >
                  {s === 'ALL' ? 'All' : s.charAt(0) + s.slice(1).toLowerCase()}
                </button>
              ))}
            </div>
          </div>
          <div className="table-wrap">
            {loading ? <div className="spinner" /> : filtered.length === 0 ? (
              <div className="empty-state">
                <div className="empty-icon">📅</div>
                <p>No appointments found.</p>
              </div>
            ) : (
              <table>
                <thead>
                  <tr><th>Patient</th><th>Doctor</th><th>Date & Time</th><th>Reason</th><th>Status</th><th>Actions</th></tr>
                </thead>
                <tbody>
                  {filtered.map(a => (
                    <tr key={a.id}>
                      <td><strong>{a.patientName}</strong></td>
                      <td>
                        <div>{a.doctorName}</div>
                        {a.doctorSpecialization && (
                          <div style={{ fontSize: '.75rem', color: 'var(--text-muted)' }}>{a.doctorSpecialization}</div>
                        )}
                      </td>
                      <td style={{ fontSize: '.82rem' }}>
                        {a.appointmentTime
                          ? new Date(a.appointmentTime).toLocaleString()
                          : '—'}
                      </td>
                      <td style={{ maxWidth: 180, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {a.reason || '—'}
                      </td>
                      <td>{statusBadge(a.status)}</td>
                      <td>
                        <div className="action-row">
                          {a.status === 'SCHEDULED' && (
                            <>
                              <button className="btn btn-sm" style={{ background: 'var(--success-light)', color: 'var(--success)', border: 'none', fontWeight: 600 }}
                                onClick={() => handleStatusChange(a, 'COMPLETED')}>✓ Done</button>
                              <button className="btn btn-sm" style={{ background: 'var(--danger-light)', color: 'var(--danger)', border: 'none', fontWeight: 600 }}
                                onClick={() => handleStatusChange(a, 'CANCELLED')}>✕ Cancel</button>
                            </>
                          )}
                          <button className="btn btn-outline btn-sm" onClick={() => openEdit(a)}>✏️</button>
                          <button className="btn btn-danger btn-sm" onClick={() => setDelTarget(a)}>🗑️</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>

      {showForm && (
        <Modal
          title={editing ? 'Edit Appointment' : 'Book Appointment'}
          onClose={() => setShowForm(false)}
          footer={
            <>
              <button className="btn btn-outline" onClick={() => setShowForm(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleSave} disabled={saving}>
                {saving ? 'Saving…' : editing ? 'Update' : 'Book'}
              </button>
            </>
          }
        >
          <div className="form-grid">
            <div className="form-group">
              <label className="form-label">Patient *</label>
              <select className="form-control" value={form.patientId} onChange={f('patientId')}>
                <option value="">Select patient</option>
                {patients.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Doctor *</label>
              <select className="form-control" value={form.doctorId} onChange={f('doctorId')}>
                <option value="">Select doctor</option>
                {doctors.map(d => <option key={d.id} value={d.id}>{d.name}{d.specialization ? ` — ${d.specialization}` : ''}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Date & Time *</label>
              <input className="form-control" type="datetime-local" value={form.appointmentTime} onChange={f('appointmentTime')} />
            </div>
            <div className="form-group">
              <label className="form-label">Status</label>
              <select className="form-control" value={form.status} onChange={f('status')}>
                {STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div className="form-group" style={{ gridColumn: '1 / -1' }}>
              <label className="form-label">Reason</label>
              <input className="form-control" value={form.reason} onChange={f('reason')} placeholder="Reason for appointment" />
            </div>
          </div>
        </Modal>
      )}

      {delTarget && (
        <ConfirmDialog
          name={`appointment for ${delTarget.patientName}`}
          onConfirm={handleDelete}
          onCancel={() => setDelTarget(null)}
          loading={deleting}
        />
      )}
    </>
  );
}

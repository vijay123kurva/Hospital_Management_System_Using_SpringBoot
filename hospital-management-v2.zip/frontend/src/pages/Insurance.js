import React, { useEffect, useState, useCallback } from 'react';
import toast from 'react-hot-toast';
import Modal from '../components/Modal';
import ConfirmDialog from '../components/ConfirmDialog';
import { getInsurances, createInsurance, updateInsurance, deleteInsurance } from '../services/api';

const EMPTY = { policyNumber: '', provider: '', validUntil: '' };

export default function Insurance() {
  const [insurances, setInsurances] = useState([]);
  const [loading,    setLoading]    = useState(true);
  const [showForm,   setShowForm]   = useState(false);
  const [editing,    setEditing]    = useState(null);
  const [form,       setForm]       = useState(EMPTY);
  const [saving,     setSaving]     = useState(false);
  const [delTarget,  setDelTarget]  = useState(null);
  const [deleting,   setDeleting]   = useState(false);

  const load = useCallback(() => {
    setLoading(true);
    getInsurances()
      .then(r => setInsurances(r.data))
      .catch(() => toast.error('Failed to load'))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { load(); }, [load]);

  const isExpired = d => d && new Date(d) < new Date();

  const openCreate = () => { setEditing(null); setForm(EMPTY); setShowForm(true); };
  const openEdit   = ins => {
    setEditing(ins);
    setForm({ policyNumber: ins.policyNumber || '', provider: ins.provider || '', validUntil: ins.validUntil || '' });
    setShowForm(true);
  };

  const handleSave = async () => {
    if (!form.policyNumber.trim()) { toast.error('Policy number required'); return; }
    if (!form.provider.trim())     { toast.error('Provider required'); return; }
    if (!form.validUntil)          { toast.error('Valid until date required'); return; }
    setSaving(true);
    try {
      if (editing) {
        await updateInsurance(editing.id, form);
        toast.success('Insurance updated');
      } else {
        await createInsurance(form);
        toast.success('Insurance created');
      }
      setShowForm(false);
      load();
    } catch { toast.error('Save failed'); }
    finally { setSaving(false); }
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await deleteInsurance(delTarget.id);
      toast.success('Insurance deleted');
      setDelTarget(null);
      load();
    } catch { toast.error('Delete failed'); }
    finally { setDeleting(false); }
  };

  const f = k => e => setForm(p => ({ ...p, [k]: e.target.value }));

  return (
    <>
      <div className="topbar">
        <span className="topbar-title">Insurance</span>
        <span className="topbar-badge">{insurances.length} policies</span>
      </div>
      <div className="page-body">
        <div className="page-header">
          <div className="page-header-left">
            <h2>Insurance Management</h2>
            <p>Manage insurance policies linked to patients</p>
          </div>
          <button className="btn btn-primary" onClick={openCreate}>＋ Add Policy</button>
        </div>

        <div className="card">
          <div className="card-header">
            <span className="card-title">All Policies</span>
          </div>
          <div className="table-wrap">
            {loading ? <div className="spinner" /> : insurances.length === 0 ? (
              <div className="empty-state">
                <div className="empty-icon">🛡️</div>
                <p>No insurance policies yet. Add one to get started.</p>
              </div>
            ) : (
              <table>
                <thead>
                  <tr><th>Policy Number</th><th>Provider</th><th>Valid Until</th><th>Patients</th><th>Status</th><th>Actions</th></tr>
                </thead>
                <tbody>
                  {insurances.map(ins => {
                    const expired = isExpired(ins.validUntil);
                    return (
                      <tr key={ins.id}>
                        <td><strong>{ins.policyNumber}</strong></td>
                        <td>{ins.provider}</td>
                        <td style={{ fontSize: '.82rem' }}>
                          {ins.validUntil ? new Date(ins.validUntil).toLocaleDateString() : '—'}
                        </td>
                        <td>
                          <span className="badge badge-scheduled">
                            {ins.patientCount} patient{ins.patientCount !== 1 ? 's' : ''}
                          </span>
                        </td>
                        <td>
                          {expired
                            ? <span className="badge badge-cancelled">Expired</span>
                            : <span className="badge badge-completed">Active</span>}
                        </td>
                        <td>
                          <div className="action-row">
                            <button className="btn btn-outline btn-sm" onClick={() => openEdit(ins)}>✏️ Edit</button>
                            <button className="btn btn-danger btn-sm" onClick={() => setDelTarget(ins)}>🗑️</button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>

      {showForm && (
        <Modal
          title={editing ? 'Edit Insurance Policy' : 'Add Insurance Policy'}
          onClose={() => setShowForm(false)}
          footer={
            <>
              <button className="btn btn-outline" onClick={() => setShowForm(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleSave} disabled={saving}>
                {saving ? 'Saving…' : editing ? 'Update' : 'Create'}
              </button>
            </>
          }
        >
          <div className="form-grid">
            <div className="form-group">
              <label className="form-label">Policy Number *</label>
              <input className="form-control" value={form.policyNumber} onChange={f('policyNumber')} placeholder="POL-2024-001" />
            </div>
            <div className="form-group">
              <label className="form-label">Provider *</label>
              <input className="form-control" value={form.provider} onChange={f('provider')} placeholder="Star Health Insurance" />
            </div>
            <div className="form-group" style={{ gridColumn: '1 / -1' }}>
              <label className="form-label">Valid Until *</label>
              <input className="form-control" type="date" value={form.validUntil} onChange={f('validUntil')} />
            </div>
          </div>
        </Modal>
      )}

      {delTarget && (
        <ConfirmDialog
          name={delTarget.policyNumber}
          message="This will unlink the policy from all associated patients."
          onConfirm={handleDelete}
          onCancel={() => setDelTarget(null)}
          loading={deleting}
        />
      )}
    </>
  );
}

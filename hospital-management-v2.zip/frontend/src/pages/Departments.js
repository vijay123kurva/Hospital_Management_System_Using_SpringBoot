import React, { useEffect, useState, useCallback } from 'react';
import toast from 'react-hot-toast';
import Modal from '../components/Modal';
import ConfirmDialog from '../components/ConfirmDialog';
import { getDepartments, createDepartment, updateDepartment, deleteDepartment, getDoctors } from '../services/api';

const EMPTY = { name: '', headDoctorId: '' };

export default function Departments() {
  const [departments, setDepartments] = useState([]);
  const [doctors,     setDoctors]     = useState([]);
  const [loading,     setLoading]     = useState(true);
  const [showForm,    setShowForm]    = useState(false);
  const [editing,     setEditing]     = useState(null);
  const [form,        setForm]        = useState(EMPTY);
  const [saving,      setSaving]      = useState(false);
  const [delTarget,   setDelTarget]   = useState(null);
  const [deleting,    setDeleting]    = useState(false);

  const load = useCallback(() => {
    setLoading(true);
    Promise.all([getDepartments(), getDoctors()])
      .then(([d, doc]) => { setDepartments(d.data); setDoctors(doc.data); })
      .catch(() => toast.error('Failed to load'))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => { setEditing(null); setForm(EMPTY); setShowForm(true); };
  const openEdit   = d => {
    setEditing(d);
    setForm({ name: d.name || '', headDoctorId: d.headDoctorId || '' });
    setShowForm(true);
  };

  const handleSave = async () => {
    if (!form.name.trim()) { toast.error('Name is required'); return; }
    setSaving(true);
    try {
      const payload = { ...form, headDoctorId: form.headDoctorId || null };
      if (editing) {
        await updateDepartment(editing.id, payload);
        toast.success('Department updated');
      } else {
        await createDepartment(payload);
        toast.success('Department created');
      }
      setShowForm(false);
      load();
    } catch { toast.error('Save failed'); }
    finally { setSaving(false); }
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await deleteDepartment(delTarget.id);
      toast.success('Department deleted');
      setDelTarget(null);
      load();
    } catch { toast.error('Delete failed'); }
    finally { setDeleting(false); }
  };

  const f = k => e => setForm(p => ({ ...p, [k]: e.target.value }));

  return (
    <>
      <div className="topbar">
        <span className="topbar-title">Departments</span>
        <span className="topbar-badge">{departments.length} departments</span>
      </div>
      <div className="page-body">
        <div className="page-header">
          <div className="page-header-left">
            <h2>Department Management</h2>
            <p>Manage hospital departments and their heads</p>
          </div>
          <button className="btn btn-primary" onClick={openCreate}>＋ Add Department</button>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 16 }}>
          {loading ? <div className="spinner" /> : departments.length === 0 ? (
            <div className="empty-state" style={{ gridColumn: '1 / -1' }}>
              <div className="empty-icon">🏥</div>
              <p>No departments yet. Create your first department.</p>
            </div>
          ) : departments.map(d => (
            <div className="card" key={d.id} style={{ padding: 0 }}>
              <div style={{ padding: '20px 20px 16px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div style={{ fontSize: '2rem', marginBottom: 8 }}>🏥</div>
                  <div className="action-row">
                    <button className="btn btn-outline btn-sm btn-icon" onClick={() => openEdit(d)}>✏️</button>
                    <button className="btn btn-danger btn-sm btn-icon" onClick={() => setDelTarget(d)}>🗑️</button>
                  </div>
                </div>
                <div style={{ fontWeight: 800, fontSize: '1.05rem', marginBottom: 4 }}>{d.name}</div>
                <div style={{ fontSize: '.8rem', color: 'var(--text-secondary)' }}>
                  {d.headDoctorName
                    ? <>Head: <strong>{d.headDoctorName}</strong></>
                    : <span style={{ color: 'var(--text-muted)' }}>No head doctor assigned</span>}
                </div>
              </div>
              <div style={{
                padding: '10px 20px',
                background: 'var(--surface-2)',
                borderTop: '1px solid var(--border)',
                display: 'flex', justifyContent: 'space-between',
                fontSize: '.78rem', color: 'var(--text-secondary)',
              }}>
                <span>👨‍⚕️ {d.doctorCount} doctor{d.doctorCount !== 1 ? 's' : ''}</span>
                <span>{d.createdAt ? new Date(d.createdAt).toLocaleDateString() : ''}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {showForm && (
        <Modal
          title={editing ? 'Edit Department' : 'Add Department'}
          onClose={() => setShowForm(false)}
          footer={
            <>
              <button className="btn btn-outline" onClick={() => setShowForm(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleSave} disabled={saving}>
                {saving ? 'Saving…' : editing ? 'Update' : 'Create'}
              </button>
            </>
          }
        >
          <div className="form-grid">
            <div className="form-group" style={{ gridColumn: '1 / -1' }}>
              <label className="form-label">Department Name *</label>
              <input className="form-control" value={form.name} onChange={f('name')} placeholder="e.g. Cardiology" />
            </div>
            <div className="form-group" style={{ gridColumn: '1 / -1' }}>
              <label className="form-label">Head Doctor</label>
              <select className="form-control" value={form.headDoctorId} onChange={f('headDoctorId')}>
                <option value="">No head doctor</option>
                {doctors.map(d => <option key={d.id} value={d.id}>{d.name}{d.specialization ? ` — ${d.specialization}` : ''}</option>)}
              </select>
            </div>
          </div>
        </Modal>
      )}

      {delTarget && (
        <ConfirmDialog
          name={delTarget.name}
          onConfirm={handleDelete}
          onCancel={() => setDelTarget(null)}
          loading={deleting}
        />
      )}
    </>
  );
}

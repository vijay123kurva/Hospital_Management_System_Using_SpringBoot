import React, { useEffect, useState, useCallback } from 'react';
import toast from 'react-hot-toast';
import Modal from '../components/Modal';
import ConfirmDialog from '../components/ConfirmDialog';
import { getDoctors, createDoctor, updateDoctor, deleteDoctor, getDepartments } from '../services/api';

const EMPTY = { name: '', specialization: '', email: '', departmentIds: [] };

export default function Doctors() {
  const [doctors,     setDoctors]     = useState([]);
  const [departments, setDepartments] = useState([]);
  const [loading,     setLoading]     = useState(true);
  const [search,      setSearch]      = useState('');
  const [showForm,    setShowForm]    = useState(false);
  const [editing,     setEditing]     = useState(null);
  const [form,        setForm]        = useState(EMPTY);
  const [saving,      setSaving]      = useState(false);
  const [delTarget,   setDelTarget]   = useState(null);
  const [deleting,    setDeleting]    = useState(false);

  const load = useCallback(() => {
    setLoading(true);
    Promise.all([getDoctors(search), getDepartments()])
      .then(([d, dep]) => { setDoctors(d.data); setDepartments(dep.data); })
      .catch(() => toast.error('Failed to load'))
      .finally(() => setLoading(false));
  }, [search]);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => { setEditing(null); setForm(EMPTY); setShowForm(true); };
  const openEdit   = d => {
    setEditing(d);
    setForm({
      name: d.name || '', specialization: d.specialization || '',
      email: d.email || '', departmentIds: d.departmentIds ? [...d.departmentIds] : [],
    });
    setShowForm(true);
  };

  const toggleDept = (id) => {
    setForm(p => ({
      ...p,
      departmentIds: p.departmentIds.includes(id)
        ? p.departmentIds.filter(x => x !== id)
        : [...p.departmentIds, id],
    }));
  };

  const handleSave = async () => {
    if (!form.name.trim()) { toast.error('Name is required'); return; }
    setSaving(true);
    try {
      if (editing) {
        await updateDoctor(editing.id, form);
        toast.success('Doctor updated');
      } else {
        await createDoctor(form);
        toast.success('Doctor created');
      }
      setShowForm(false);
      load();
    } catch { toast.error('Save failed'); }
    finally { setSaving(false); }
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await deleteDoctor(delTarget.id);
      toast.success('Doctor deleted');
      setDelTarget(null);
      load();
    } catch { toast.error('Delete failed'); }
    finally { setDeleting(false); }
  };

  const f = k => e => setForm(p => ({ ...p, [k]: e.target.value }));

  return (
    <>
      <div className="topbar">
        <span className="topbar-title">Doctors</span>
        <span className="topbar-badge">{doctors.length} records</span>
      </div>
      <div className="page-body">
        <div className="page-header">
          <div className="page-header-left">
            <h2>Doctor Management</h2>
            <p>Manage medical staff and department assignments</p>
          </div>
          <button className="btn btn-primary" onClick={openCreate}>＋ Add Doctor</button>
        </div>

        <div className="card">
          <div className="card-header">
            <span className="card-title">All Doctors</span>
            <div className="search-bar">
              <span className="search-icon">🔍</span>
              <input placeholder="Search by name…" value={search} onChange={e => setSearch(e.target.value)} />
            </div>
          </div>
          <div className="table-wrap">
            {loading ? <div className="spinner" /> : doctors.length === 0 ? (
              <div className="empty-state">
                <div className="empty-icon">👨‍⚕️</div>
                <p>No doctors found. Add your first doctor.</p>
              </div>
            ) : (
              <table>
                <thead>
                  <tr><th>Name</th><th>Specialization</th><th>Email</th><th>Departments</th><th>Joined</th><th>Actions</th></tr>
                </thead>
                <tbody>
                  {doctors.map(d => (
                    <tr key={d.id}>
                      <td><strong>{d.name}</strong></td>
                      <td>{d.specialization
                        ? <span className="badge badge-scheduled">{d.specialization}</span>
                        : '—'}
                      </td>
                      <td>{d.email || '—'}</td>
                      <td>
                        {d.departmentNames && d.departmentNames.size > 0
                          ? [...d.departmentNames].map(n => (
                              <span key={n} className="badge badge-completed" style={{ marginRight: 4 }}>{n}</span>
                            ))
                          : <span style={{ color: 'var(--text-muted)', fontSize: '.8rem' }}>Unassigned</span>}
                      </td>
                      <td style={{ color: 'var(--text-secondary)', fontSize: '.82rem' }}>
                        {d.createdAt ? new Date(d.createdAt).toLocaleDateString() : '—'}
                      </td>
                      <td>
                        <div className="action-row">
                          <button className="btn btn-outline btn-sm" onClick={() => openEdit(d)}>✏️ Edit</button>
                          <button className="btn btn-danger btn-sm" onClick={() => setDelTarget(d)}>🗑️</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>

      {showForm && (
        <Modal
          title={editing ? 'Edit Doctor' : 'Add Doctor'}
          onClose={() => setShowForm(false)}
          footer={
            <>
              <button className="btn btn-outline" onClick={() => setShowForm(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleSave} disabled={saving}>
                {saving ? 'Saving…' : editing ? 'Update' : 'Create'}
              </button>
            </>
          }
        >
          <div className="form-grid">
            <div className="form-group">
              <label className="form-label">Full Name *</label>
              <input className="form-control" value={form.name} onChange={f('name')} placeholder="Dr. Jane Smith" />
            </div>
            <div className="form-group">
              <label className="form-label">Specialization</label>
              <input className="form-control" value={form.specialization} onChange={f('specialization')} placeholder="Cardiology" />
            </div>
            <div className="form-group" style={{ gridColumn: '1 / -1' }}>
              <label className="form-label">Email</label>
              <input className="form-control" type="email" value={form.email} onChange={f('email')} placeholder="doctor@hospital.com" />
            </div>
            {departments.length > 0 && (
              <div className="form-group" style={{ gridColumn: '1 / -1' }}>
                <label className="form-label">Departments</label>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 4 }}>
                  {departments.map(dep => {
                    const checked = form.departmentIds.includes(dep.id);
                    return (
                      <label key={dep.id} style={{
                        display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer',
                        padding: '6px 12px', borderRadius: 8,
                        border: `2px solid ${checked ? 'var(--primary)' : 'var(--border)'}`,
                        background: checked ? 'var(--primary-pale)' : 'var(--surface)',
                        fontSize: '.83rem', fontWeight: 600, transition: 'all .15s',
                      }}>
                        <input type="checkbox" checked={checked} onChange={() => toggleDept(dep.id)} style={{ display: 'none' }} />
                        {checked ? '✓ ' : ''}{dep.name}
                      </label>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </Modal>
      )}

      {delTarget && (
        <ConfirmDialog
          name={delTarget.name}
          onConfirm={handleDelete}
          onCancel={() => setDelTarget(null)}
          loading={deleting}
        />
      )}
    </>
  );
}

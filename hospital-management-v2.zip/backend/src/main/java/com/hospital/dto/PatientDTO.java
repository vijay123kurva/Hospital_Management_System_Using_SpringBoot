package com.hospital.dto;

import lombok.Data;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class PatientDTO {
    private Long id;
    private String name;
    private String gender;
    private LocalDate birthDate;
    private String email;
    private String bloodGroup;
    private LocalDateTime createdAt;
    private Long insuranceId;
    private String insurancePolicyNumber;
    private String insuranceProvider;
}

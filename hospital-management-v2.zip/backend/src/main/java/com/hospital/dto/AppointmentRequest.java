package com.hospital.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class AppointmentRequest {
    @NotNull
    private LocalDateTime appointmentTime;
    private String reason;
    private String status = "SCHEDULED";
    @NotNull
    private Long doctorId;
    @NotNull
    private Long patientId;
}

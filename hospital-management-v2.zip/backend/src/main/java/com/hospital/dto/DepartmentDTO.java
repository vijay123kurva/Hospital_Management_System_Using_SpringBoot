package com.hospital.dto;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class DepartmentDTO {
    private Long id;
    private String name;
    private LocalDateTime createdAt;
    private Long headDoctorId;
    private String headDoctorName;
    private int doctorCount;
}

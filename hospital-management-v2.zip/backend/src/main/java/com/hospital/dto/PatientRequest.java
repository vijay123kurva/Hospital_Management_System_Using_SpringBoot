package com.hospital.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import java.time.LocalDate;

@Data
public class PatientRequest {
    @NotBlank
    private String name;
    private String gender;
    private LocalDate birthDate;
    @Email
    private String email;
    private String bloodGroup;
    private Long insuranceId;
}

package com.hospital.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.time.LocalDate;

@Data
public class InsuranceRequest {
    @NotBlank
    private String policyNumber;
    @NotBlank
    private String provider;
    @NotNull
    private LocalDate validUntil;
}

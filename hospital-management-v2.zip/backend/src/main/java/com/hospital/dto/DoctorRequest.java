package com.hospital.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import java.util.Set;

@Data
public class DoctorRequest {
    @NotBlank
    private String name;
    private String specialization;
    @Email
    private String email;
    private Set<Long> departmentIds;
}

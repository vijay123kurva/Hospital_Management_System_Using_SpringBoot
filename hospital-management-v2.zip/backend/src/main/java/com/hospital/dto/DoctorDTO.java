package com.hospital.dto;

import lombok.Data;
import java.time.LocalDateTime;
import java.util.Set;

@Data
public class DoctorDTO {
    private Long id;
    private String name;
    private String specialization;
    private String email;
    private LocalDateTime createdAt;
    private Set<Long> departmentIds;
    private Set<String> departmentNames;
}

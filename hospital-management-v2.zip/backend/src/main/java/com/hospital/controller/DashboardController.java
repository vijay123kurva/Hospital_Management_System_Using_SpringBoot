package com.hospital.controller;

import com.hospital.dto.DashboardDTO;
import com.hospital.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/dashboard")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:3000")
public class DashboardController {

    private final PatientRepository patientRepository;
    private final DoctorRepository doctorRepository;
    private final DepartmentRepository departmentRepository;
    private final AppointmentRepository appointmentRepository;
    private final InsuranceRepository insuranceRepository;

    @GetMapping
    public ResponseEntity<DashboardDTO> getDashboardStats() {
        DashboardDTO dto = new DashboardDTO(
                patientRepository.count(),
                doctorRepository.count(),
                departmentRepository.count(),
                appointmentRepository.count(),
                appointmentRepository.countByStatus("SCHEDULED"),
                appointmentRepository.countByStatus("COMPLETED"),
                appointmentRepository.countByStatus("CANCELLED"),
                insuranceRepository.count()
        );
        return ResponseEntity.ok(dto);
    }
}

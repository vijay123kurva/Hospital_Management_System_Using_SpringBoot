package com.hospital.controller;

import com.hospital.dto.InsuranceDTO;
import com.hospital.dto.InsuranceRequest;
import com.hospital.service.InsuranceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/insurances")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:3000")
public class InsuranceController {

    private final InsuranceService insuranceService;

    @GetMapping
    public ResponseEntity<List<InsuranceDTO>> getAllInsurances() {
        return ResponseEntity.ok(insuranceService.getAllInsurances());
    }

    @GetMapping("/{id}")
    public ResponseEntity<InsuranceDTO> getInsuranceById(@PathVariable Long id) {
        return ResponseEntity.ok(insuranceService.getInsuranceById(id));
    }

    @PostMapping
    public ResponseEntity<InsuranceDTO> createInsurance(@Valid @RequestBody InsuranceRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(insuranceService.createInsurance(request));
    }

    @PutMapping("/{id}")
    public ResponseEntity<InsuranceDTO> updateInsurance(@PathVariable Long id, @Valid @RequestBody InsuranceRequest request) {
        return ResponseEntity.ok(insuranceService.updateInsurance(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteInsurance(@PathVariable Long id) {
        insuranceService.deleteInsurance(id);
        return ResponseEntity.noContent().build();
    }
}

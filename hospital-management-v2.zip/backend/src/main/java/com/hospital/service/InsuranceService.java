package com.hospital.service;

import com.hospital.dto.InsuranceDTO;
import com.hospital.dto.InsuranceRequest;
import com.hospital.entity.Insurance;
import com.hospital.repository.InsuranceRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class InsuranceService {

    private final InsuranceRepository insuranceRepository;

    public List<InsuranceDTO> getAllInsurances() {
        return insuranceRepository.findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    public InsuranceDTO getInsuranceById(Long id) {
        return insuranceRepository.findById(id).map(this::toDTO)
                .orElseThrow(() -> new RuntimeException("Insurance not found with id: " + id));
    }

    public InsuranceDTO createInsurance(InsuranceRequest request) {
        Insurance insurance = new Insurance();
        mapRequestToEntity(request, insurance);
        return toDTO(insuranceRepository.save(insurance));
    }

    public InsuranceDTO updateInsurance(Long id, InsuranceRequest request) {
        Insurance insurance = insuranceRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Insurance not found with id: " + id));
        mapRequestToEntity(request, insurance);
        return toDTO(insuranceRepository.save(insurance));
    }

    public void deleteInsurance(Long id) {
        insuranceRepository.deleteById(id);
    }

    private void mapRequestToEntity(InsuranceRequest request, Insurance insurance) {
        insurance.setPolicyNumber(request.getPolicyNumber());
        insurance.setProvider(request.getProvider());
        insurance.setValidUntil(request.getValidUntil());
    }

    public InsuranceDTO toDTO(Insurance i) {
        InsuranceDTO dto = new InsuranceDTO();
        dto.setId(i.getId());
        dto.setPolicyNumber(i.getPolicyNumber());
        dto.setProvider(i.getProvider());
        dto.setValidUntil(i.getValidUntil());
        dto.setCreatedAt(i.getCreatedAt());
        dto.setPatientCount(i.getPatients() != null ? i.getPatients().size() : 0);
        return dto;
    }
}

package com.hospital.service;

import com.hospital.dto.DepartmentDTO;
import com.hospital.dto.DepartmentRequest;
import com.hospital.entity.Department;
import com.hospital.entity.Doctor;
import com.hospital.repository.DepartmentRepository;
import com.hospital.repository.DoctorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class DepartmentService {

    private final DepartmentRepository departmentRepository;
    private final DoctorRepository doctorRepository;

    public List<DepartmentDTO> getAllDepartments() {
        return departmentRepository.findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    public DepartmentDTO getDepartmentById(Long id) {
        return departmentRepository.findById(id).map(this::toDTO)
                .orElseThrow(() -> new RuntimeException("Department not found with id: " + id));
    }

    public DepartmentDTO createDepartment(DepartmentRequest request) {
        Department department = new Department();
        mapRequestToEntity(request, department);
        return toDTO(departmentRepository.save(department));
    }

    public DepartmentDTO updateDepartment(Long id, DepartmentRequest request) {
        Department department = departmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Department not found with id: " + id));
        mapRequestToEntity(request, department);
        return toDTO(departmentRepository.save(department));
    }

    public void deleteDepartment(Long id) {
        departmentRepository.deleteById(id);
    }

    private void mapRequestToEntity(DepartmentRequest request, Department department) {
        department.setName(request.getName());
        if (request.getHeadDoctorId() != null) {
            Doctor doctor = doctorRepository.findById(request.getHeadDoctorId())
                    .orElseThrow(() -> new RuntimeException("Doctor not found"));
            department.setHeadDoctor(doctor);
        } else {
            department.setHeadDoctor(null);
        }
    }

    public DepartmentDTO toDTO(Department d) {
        DepartmentDTO dto = new DepartmentDTO();
        dto.setId(d.getId());
        dto.setName(d.getName());
        dto.setCreatedAt(d.getCreatedAt());
        if (d.getHeadDoctor() != null) {
            dto.setHeadDoctorId(d.getHeadDoctor().getId());
            dto.setHeadDoctorName(d.getHeadDoctor().getName());
        }
        dto.setDoctorCount(d.getDoctors() != null ? d.getDoctors().size() : 0);
        return dto;
    }
}

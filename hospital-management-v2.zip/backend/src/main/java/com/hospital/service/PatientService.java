package com.hospital.service;

import com.hospital.dto.PatientDTO;
import com.hospital.dto.PatientRequest;
import com.hospital.entity.Insurance;
import com.hospital.entity.Patient;
import com.hospital.repository.InsuranceRepository;
import com.hospital.repository.PatientRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class PatientService {

    private final PatientRepository patientRepository;
    private final InsuranceRepository insuranceRepository;

    public List<PatientDTO> getAllPatients() {
        return patientRepository.findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    public PatientDTO getPatientById(Long id) {
        return patientRepository.findById(id).map(this::toDTO)
                .orElseThrow(() -> new RuntimeException("Patient not found with id: " + id));
    }

    public PatientDTO createPatient(PatientRequest request) {
        Patient patient = new Patient();
        mapRequestToEntity(request, patient);
        return toDTO(patientRepository.save(patient));
    }

    public PatientDTO updatePatient(Long id, PatientRequest request) {
        Patient patient = patientRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Patient not found with id: " + id));
        mapRequestToEntity(request, patient);
        return toDTO(patientRepository.save(patient));
    }

    public void deletePatient(Long id) {
        patientRepository.deleteById(id);
    }

    public List<PatientDTO> searchPatients(String name) {
        return patientRepository.findByNameContainingIgnoreCase(name)
                .stream().map(this::toDTO).collect(Collectors.toList());
    }

    private void mapRequestToEntity(PatientRequest request, Patient patient) {
        patient.setName(request.getName());
        patient.setGender(request.getGender());
        patient.setBirthDate(request.getBirthDate());
        patient.setEmail(request.getEmail());
        patient.setBloodGroup(request.getBloodGroup());
        if (request.getInsuranceId() != null) {
            Insurance insurance = insuranceRepository.findById(request.getInsuranceId())
                    .orElseThrow(() -> new RuntimeException("Insurance not found"));
            patient.setInsurance(insurance);
        } else {
            patient.setInsurance(null);
        }
    }

    public PatientDTO toDTO(Patient p) {
        PatientDTO dto = new PatientDTO();
        dto.setId(p.getId());
        dto.setName(p.getName());
        dto.setGender(p.getGender());
        dto.setBirthDate(p.getBirthDate());
        dto.setEmail(p.getEmail());
        dto.setBloodGroup(p.getBloodGroup());
        dto.setCreatedAt(p.getCreatedAt());
        if (p.getInsurance() != null) {
            dto.setInsuranceId(p.getInsurance().getId());
            dto.setInsurancePolicyNumber(p.getInsurance().getPolicyNumber());
            dto.setInsuranceProvider(p.getInsurance().getProvider());
        }
        return dto;
    }
}

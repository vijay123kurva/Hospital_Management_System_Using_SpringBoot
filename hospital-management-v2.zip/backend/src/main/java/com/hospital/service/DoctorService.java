package com.hospital.service;

import com.hospital.dto.DoctorDTO;
import com.hospital.dto.DoctorRequest;
import com.hospital.entity.Department;
import com.hospital.entity.Doctor;
import com.hospital.repository.DepartmentRepository;
import com.hospital.repository.DoctorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class DoctorService {

    private final DoctorRepository doctorRepository;
    private final DepartmentRepository departmentRepository;

    public List<DoctorDTO> getAllDoctors() {
        return doctorRepository.findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    public DoctorDTO getDoctorById(Long id) {
        return doctorRepository.findById(id).map(this::toDTO)
                .orElseThrow(() -> new RuntimeException("Doctor not found with id: " + id));
    }

    public DoctorDTO createDoctor(DoctorRequest request) {
        Doctor doctor = new Doctor();
        mapRequestToEntity(request, doctor);
        return toDTO(doctorRepository.save(doctor));
    }

    public DoctorDTO updateDoctor(Long id, DoctorRequest request) {
        Doctor doctor = doctorRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Doctor not found with id: " + id));
        mapRequestToEntity(request, doctor);
        return toDTO(doctorRepository.save(doctor));
    }

    public void deleteDoctor(Long id) {
        doctorRepository.deleteById(id);
    }

    public List<DoctorDTO> searchDoctors(String name) {
        return doctorRepository.findByNameContainingIgnoreCase(name)
                .stream().map(this::toDTO).collect(Collectors.toList());
    }

    private void mapRequestToEntity(DoctorRequest request, Doctor doctor) {
        doctor.setName(request.getName());
        doctor.setSpecialization(request.getSpecialization());
        doctor.setEmail(request.getEmail());
        if (request.getDepartmentIds() != null && !request.getDepartmentIds().isEmpty()) {
            Set<Department> departments = new HashSet<>(
                    departmentRepository.findAllById(request.getDepartmentIds()));
            doctor.setDepartments(departments);
        } else {
            doctor.setDepartments(new HashSet<>());
        }
    }

    public DoctorDTO toDTO(Doctor d) {
        DoctorDTO dto = new DoctorDTO();
        dto.setId(d.getId());
        dto.setName(d.getName());
        dto.setSpecialization(d.getSpecialization());
        dto.setEmail(d.getEmail());
        dto.setCreatedAt(d.getCreatedAt());
        if (d.getDepartments() != null) {
            dto.setDepartmentIds(d.getDepartments().stream().map(Department::getId).collect(Collectors.toSet()));
            dto.setDepartmentNames(d.getDepartments().stream().map(Department::getName).collect(Collectors.toSet()));
        }
        return dto;
    }
}
